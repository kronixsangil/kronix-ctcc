// app/(cc)/drivers/[driverId]/page.tsx
// app/(cc)/drivers/[driverId]/page.tsx
"use client";

import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import { apiFetch } from "@/lib/api";
import { formatCOP, toISODate } from "@/lib/format";
import { useCtccCity } from "../../components/CtccCityContext";

type WorkerTab = "GENERAL" | "TYPES" | "WALLET" | "VEHICLE" | "DOCUMENTS" | "HISTORY";

type WorkerTypeCode = "MOTORCYCLE" | "TAXI" | "MOTORCARGO";

type DriverDocumentCheck = {
  id?: string;
  type: string;
  status: string;
  documentNumber?: string | null;
  expiresAt?: string | null;
  internalNotes?: string | null;
  waiverReason?: string | null;
  waiverExpiresAt?: string | null;
};

type WorkerProfileResponse = {
  ok: true;
  user: {
    id: string;
    name: string;
    phone: string;
    email: string | null;
    profileImageUrl?: string | null;
  };
  driverProfile: any;
  vehicle: any | null;
  docs: any;
  inactiveInfo: any;
  history: {
    orders: any[];
    payouts: any[];
    bonuses?: any[];
    sanctions?: any[];
  };
};

type CityOption = {
  id: string;
  slug: string;
  name: string;
  department: string;
  country?: string | null;
};

const WORKER_TYPE_OPTIONS: Array<{
  value: WorkerTypeCode;
  label: string;
  hint: string;
  tone: string;
}> = [
  {
    value: "MOTORCYCLE",
    label: "Domiciliario",
    hint: "Delivery + Envíos",
    tone: "border-emerald-200 bg-emerald-50 text-emerald-700",
  },
  {
    value: "TAXI",
    label: "Taxista",
    hint: "Taxi",
    tone: "border-amber-200 bg-amber-50 text-amber-800",
  },
  {
    value: "MOTORCARGO",
    label: "Motocarguero",
    hint: "Motocarga",
    tone: "border-violet-200 bg-violet-50 text-violet-700",
  },
];

const DOCUMENT_TYPES = [
  "ID_CARD",
  "DRIVER_LICENSE",
  "SELFIE_OR_PROFILE_PHOTO",
  "SOAT",
  "TECHNOMECHANICAL",
  "VEHICLE_OWNERSHIP_CARD",
  "VEHICLE_PHOTO_OR_INSPECTION",
  "BACKGROUND_CHECK",
] as const;

const DOCUMENT_LABELS: Record<string, string> = {
  ID_CARD: "Cédula",
  DRIVER_LICENSE: "Licencia de conducción",
  SELFIE_OR_PROFILE_PHOTO: "Selfie / Foto presencial",
  SOAT: "SOAT",
  TECHNOMECHANICAL: "Tecnomecánica",
  VEHICLE_OWNERSHIP_CARD: "Tarjeta de propiedad",
  VEHICLE_PHOTO_OR_INSPECTION: "Foto / Inspección vehículo",
  BACKGROUND_CHECK: "Antecedentes",
};

function isoToDateInput(v?: string | null) {
  if (!v) return "";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return "";
  return toISODate(d);
}

function dateInputToIsoOrNull(v: string) {
  const x = String(v || "").trim();
  if (!x) return null;
  const d = new Date(`${x}T00:00:00`);
  if (Number.isNaN(d.getTime())) return null;
  return d.toISOString();
}

function driverPhotoFileNameFromUrl(value?: string | null) {
  const raw = String(value ?? "").trim();
  if (!raw) return "";
  const clean = raw.replace(/^\/branding\/Driver_Pictures\//, "");
  return clean.split(/[\\/]/).pop() ?? "";
}

function buildDriverPhotoSrc(value?: string | null) {
  const file = driverPhotoFileNameFromUrl(value);
  if (!file) return "";
  return `/branding/Driver_Pictures/${file.split("/").map(encodeURIComponent).join("/")}`;
}

function normalizeDriverPhotoPath(value?: string | null) {
  const file = driverPhotoFileNameFromUrl(value);
  return file ? `/branding/Driver_Pictures/${file}` : null;
}

function levelLabel(lvl?: string | null) {
  const v = String(lvl ?? "").toUpperCase();
  if (v === "PLATINO") return "Platino";
  if (v === "ORO") return "Oro";
  if (v === "PLATA") return "Plata";
  return "Bronce";
}

function statusBadgeClass(status?: string | null) {
  const s = String(status ?? "").toUpperCase();
  if (s === "APPROVED" || s === "VERIFIED") return "border-emerald-200 bg-emerald-50 text-emerald-700";
  if (s === "TEMPORARY_APPROVED") return "border-blue-200 bg-blue-50 text-blue-700";
  if (s === "REJECTED" || s === "EXPIRED" || s === "BLOCKED") return "border-rose-200 bg-rose-50 text-rose-700";
  return "border-amber-200 bg-amber-50 text-amber-700";
}

function StatCard({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="text-xs font-black uppercase tracking-wide text-slate-500">{label}</div>
      <div className="mt-2 text-2xl font-black text-slate-950">{value}</div>
      {hint ? <div className="mt-1 text-xs text-slate-500">{hint}</div> : null}
    </div>
  );
}

function TabButton({ active, label, onClick }: { active: boolean; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={[
        "rounded-xl border px-4 py-2 text-sm font-bold transition",
        active
          ? "border-slate-900 bg-slate-900 text-white shadow-sm"
          : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50",
      ].join(" ")}
    >
      {label}
    </button>
  );
}

export default function WorkerProfilePage() {
  const params = useParams<{ driverId: string }>();
  const router = useRouter();
  const { mode, citySlug: globalCitySlug, cityLabel } = useCtccCity();

  const driverId = String(params?.driverId ?? "").trim();
  const effectiveCitySlug = mode === "CITY" && globalCitySlug ? globalCitySlug : "";

  const [tab, setTab] = useState<WorkerTab>("GENERAL");
  const [profile, setProfile] = useState<WorkerProfileResponse | null>(null);
  const [eligibility, setEligibility] = useState<any | null>(null);
  const [documentChecks, setDocumentChecks] = useState<DriverDocumentCheck[]>([]);
  const [workerTypesData, setWorkerTypesData] = useState<any | null>(null);
  const [workerWalletData, setWorkerWalletData] = useState<any | null>(null);
  const [selectedWorkerTypes, setSelectedWorkerTypes] = useState<string[]>([]);
  const [selectedServiceKeys, setSelectedServiceKeys] = useState<string[]>([]);
  const [availableServices, setAvailableServices] = useState<any[]>([]);

  const [loading, setLoading] = useState(true);
  const [savingTypes, setSavingTypes] = useState(false);
  const [savingWallet, setSavingWallet] = useState(false);
  const [savingVehicle, setSavingVehicle] = useState(false);
  const [savingDocument, setSavingDocument] = useState<string | null>(null);
  const [savingPhoto, setSavingPhoto] = useState(false);
  const [photoFileName, setPhotoFileName] = useState("");
  const [savingGeneral, setSavingGeneral] = useState(false);
  const [cities, setCities] = useState<CityOption[]>([]);
  const [generalForm, setGeneralForm] = useState({
    name: "",
    phone: "",
    email: "",
    documentId: "",
    citySlug: "",
    password: "",
    isActive: false,
  });
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const [walletAmountCOP, setWalletAmountCOP] = useState("");
  const [walletNote, setWalletNote] = useState("Recarga manual CTCC");

  const [vehicleForm, setVehicleForm] = useState({
    plate: "",
    brand: "",
    color: "",
    model: "",
    isActive: true,
    soatNumber: "",
    soatExpiresAt: "",
    tecnicomecanicaNumber: "",
    tecnicomecanicaExpiresAt: "",
  });

  useEffect(() => {
    let cancelled = false;

    async function loadCities() {
      try {
        const res = await apiFetch<any>("/public/cities", { method: "GET" });
        const items = Array.isArray(res?.items) ? res.items : [];
        if (!cancelled) {
          setCities(
            items
              .map((city: any) => ({
                id: String(city?.id ?? ""),
                slug: String(city?.slug ?? ""),
                name: String(city?.name ?? ""),
                department: String(city?.department ?? ""),
                country: city?.country != null ? String(city.country) : null,
              }))
              .filter((city: CityOption) => city.slug && city.name)
          );
        }
      } catch {
        // La edición general sigue funcionando con la ciudad actual del perfil.
      }
    }

    void loadCities();
    return () => { cancelled = true; };
  }, []);

  const workerTypeHint = useMemo(() => {
    const serviceNames = availableServices
      .filter((service) =>
        selectedServiceKeys.includes(
          String(service.serviceKey ?? "").trim().toUpperCase()
        )
      )
      .map((service) => String(service.shortName || service.name || service.serviceKey));

    if (serviceNames.length) return serviceNames.join(" · ");

    return "Sin servicios autorizados";
  }, [availableServices, selectedServiceKeys, selectedWorkerTypes]);

  const loadWallet = useCallback(async () => {
    if (!driverId) return;

    const qs = new URLSearchParams();
    if (effectiveCitySlug) qs.set("citySlug", effectiveCitySlug);
    qs.set("take", "20");

    const walletRes = await apiFetch<any>(
      `/drivers/admin/${driverId}/wallet${qs.toString() ? `?${qs.toString()}` : ""}`
    );
    setWorkerWalletData(walletRes);
  }, [driverId, effectiveCitySlug]);

  const loadProfile = useCallback(async () => {
    if (!driverId) return;

    setLoading(true);
    setError(null);
    setMessage(null);

    try {
      const data = await apiFetch<WorkerProfileResponse>(`/drivers/admin/${driverId}`);
      setProfile(data);
      setGeneralForm({
        name: String(data.user?.name ?? ""),
        phone: String(data.user?.phone ?? ""),
        email: String(data.user?.email ?? ""),
        documentId: String(data.driverProfile?.documentId ?? ""),
        citySlug: String(data.driverProfile?.city?.slug ?? effectiveCitySlug ?? ""),
        password: "",
        isActive: Boolean(data.driverProfile?.isActive),
      });
      setPhotoFileName(
        driverPhotoFileNameFromUrl(data.user?.profileImageUrl ?? null)
      );

      const v = data.vehicle || null;
      setVehicleForm({
        plate: String(v?.plate ?? ""),
        brand: String(v?.brand ?? ""),
        color: String(v?.color ?? ""),
        model: String(v?.model ?? ""),
        isActive: Boolean(v?.isActive ?? true),
        soatNumber: String(v?.soatNumber ?? ""),
        soatExpiresAt: isoToDateInput(v?.soatExpiresAt ?? null),
        tecnicomecanicaNumber: String(v?.tecnicomecanicaNumber ?? ""),
        tecnicomecanicaExpiresAt: isoToDateInput(v?.tecnicomecanicaExpiresAt ?? null),
      });

      const [el, docsRes, workerTypesRes] = await Promise.all([
        apiFetch<any>(`/drivers/admin/${driverId}/eligibility`),
        apiFetch<any>(`/drivers/admin/${driverId}/documents`),
        apiFetch<any>(
          `/drivers/admin/${driverId}/worker-types${effectiveCitySlug ? `?citySlug=${encodeURIComponent(effectiveCitySlug)}` : ""}`
        ),
      ]);

      setEligibility(el);
      setDocumentChecks(Array.isArray(docsRes?.documents) ? docsRes.documents : []);
      setWorkerTypesData(workerTypesRes);
      setAvailableServices(Array.isArray(workerTypesRes?.availableServices) ? workerTypesRes.availableServices : []);
      setSelectedServiceKeys(
        Array.isArray(workerTypesRes?.selectedServiceKeys)
          ? workerTypesRes.selectedServiceKeys.map((item: any) =>
              String(item ?? "").trim().toUpperCase()
            )
          : []
      );
      setSelectedWorkerTypes(
        Array.isArray(workerTypesRes?.workerTypes)
          ? workerTypesRes.workerTypes.map((item: any) => String(item ?? "").trim().toUpperCase())
          : []
      );

      await loadWallet();
    } catch (e: any) {
      setError(e?.message || "No se pudo cargar el perfil del worker");
    } finally {
      setLoading(false);
    }
  }, [driverId, effectiveCitySlug, loadWallet]);

  useEffect(() => {
    loadProfile();
  }, [loadProfile]);

  function toggleWorkerType(value: WorkerTypeCode) {
    setSelectedWorkerTypes((current) => {
      if (current.includes(value)) return current.filter((item) => item !== value);
      return [...current, value];
    });
  }

  async function saveWorkerTypes() {
    if (!driverId) return;

    setSavingTypes(true);
    setError(null);
    setMessage(null);

    try {
      // El perfil administra exclusivamente autorizaciones dinámicas.
      // Nunca vuelve a crear tipos legacy MOTORCYCLE/TAXI/MOTORCARGO.
      const body: any = { serviceKeys: selectedServiceKeys };
      if (effectiveCitySlug) body.citySlug = effectiveCitySlug;

      const res = await apiFetch<any>(`/drivers/admin/${driverId}/worker-types`, {
        method: "PATCH",
        body: JSON.stringify(body),
      });

      setWorkerTypesData(res);
      setAvailableServices(Array.isArray(res?.availableServices) ? res.availableServices : availableServices);
      setSelectedServiceKeys(Array.isArray(res?.selectedServiceKeys) ? res.selectedServiceKeys : selectedServiceKeys);
      setSelectedWorkerTypes(
        Array.isArray(res?.workerTypes) && res.workerTypes.length
          ? res.workerTypes.map((item: any) => String(item ?? "").trim().toUpperCase())
          : selectedWorkerTypes
      );
      setMessage("Servicios autorizados guardados ✅");
    } catch (e: any) {
      setError(e?.message || "No se pudieron guardar los tipos autorizados");
    } finally {
      setSavingTypes(false);
    }
  }

  async function adjustWorkerWallet(multiplier: 1 | -1) {
    const rawAmount = Math.round(Number(walletAmountCOP || 0));
    const amountCOP = rawAmount * multiplier;

    if (!Number.isFinite(rawAmount) || rawAmount <= 0) {
      setMessage("Ingresa un valor mayor a cero.");
      return;
    }

    if (walletNote.trim().length < 5) {
      setMessage("La nota debe tener mínimo 5 caracteres.");
      return;
    }

    setSavingWallet(true);
    setError(null);
    setMessage(null);

    try {
      const body: any = {
        amountCOP,
        bucket: "CASH",
        note: walletNote.trim(),
      };
      if (effectiveCitySlug) body.citySlug = effectiveCitySlug;

      await apiFetch<any>(`/drivers/admin/${driverId}/wallet/adjust`, {
        method: "POST",
        body: JSON.stringify(body),
      });

      setWalletAmountCOP("");
      await loadWallet();
      setMessage(multiplier > 0 ? "Recarga aplicada ✅" : "Débito aplicado ✅");
    } catch (e: any) {
      setError(e?.message || "No se pudo ajustar la Wallet KRONIX");
    } finally {
      setSavingWallet(false);
    }
  }

  async function saveGeneral() {
    if (!driverId || !profile) return;

    const name = generalForm.name.trim();
    const phone = generalForm.phone.replace(/\D/g, "").trim();
    const email = generalForm.email.trim();
    const documentId = generalForm.documentId.trim();
    const password = generalForm.password.trim();
    const citySlug = generalForm.citySlug.trim();

    if (!name) {
      setError("El nombre es obligatorio.");
      return;
    }
    if (!phone) {
      setError("El teléfono es obligatorio.");
      return;
    }
    if (!citySlug) {
      setError("Selecciona una ciudad para el trabajador.");
      return;
    }
    if (password && password.length < 6) {
      setError("La nueva contraseña debe tener mínimo 6 caracteres.");
      return;
    }

    setSavingGeneral(true);
    setError(null);
    setMessage(null);

    try {
      // Datos/credenciales: jamás enviamos workerTypes ni serviceKeys aquí.
      await apiFetch(`/admin/users/drivers/${driverId}`, {
        method: "PATCH",
        body: JSON.stringify({
          name,
          phone,
          email: email || null,
          documentId: documentId || null,
          citySlug,
          ...(password ? { password } : {}),
        }),
      });

      // Activación operativa se guarda por su endpoint específico, separado
      // de las autorizaciones dinámicas.
      const currentActive = Boolean(profile.driverProfile?.isActive);
      if (currentActive !== generalForm.isActive) {
        await apiFetch(`/drivers/admin/${driverId}/active`, {
          method: "PATCH",
          body: JSON.stringify({
            isActive: generalForm.isActive,
            reason: generalForm.isActive
              ? "Activación desde CTCC / Perfil del Worker"
              : "Desactivación desde CTCC / Perfil del Worker",
          }),
        });
      }

      setGeneralForm((current) => ({ ...current, password: "" }));
      setMessage("Información general del trabajador guardada ✅");
      await loadProfile();
    } catch (e: any) {
      setError(e?.message || "No se pudo actualizar la información del trabajador");
    } finally {
      setSavingGeneral(false);
    }
  }

  async function saveOfficialPhoto() {
    if (!driverId) return;

    const fileName = driverPhotoFileNameFromUrl(photoFileName);

    if (!fileName) {
      setError("Escribe el nombre exacto del archivo de la foto.");
      setMessage(null);
      return;
    }

    if (!/\.(jpe?g|png|webp)$/i.test(fileName)) {
      setError("Usa un archivo JPG, JPEG, PNG o WEBP.");
      setMessage(null);
      return;
    }

    setSavingPhoto(true);
    setError(null);
    setMessage(null);

    try {
      const res = await apiFetch<any>(
        `/drivers/admin/${driverId}/profile-photo`,
        {
          method: "PATCH",
          body: JSON.stringify({ fileName }),
        }
      );

      const savedPath =
        String(res?.profileImageUrl ?? "").trim() ||
        normalizeDriverPhotoPath(fileName);

      setPhotoFileName(driverPhotoFileNameFromUrl(savedPath));

      setProfile((current) =>
        current
          ? {
              ...current,
              user: {
                ...current.user,
                profileImageUrl: savedPath,
              },
            }
          : current
      );

      setMessage("Foto oficial del trabajador guardada ✅");
    } catch (e: any) {
      setError(
        e?.message ||
          "No se pudo guardar la foto oficial del trabajador"
      );
    } finally {
      setSavingPhoto(false);
    }
  }

  async function saveVehicle() {
    setSavingVehicle(true);
    setError(null);
    setMessage(null);

    try {
      await apiFetch(`/drivers/admin/${driverId}/vehicle`, {
        method: "PATCH",
        body: JSON.stringify({
          plate: vehicleForm.plate.trim() || null,
          brand: vehicleForm.brand.trim() || null,
          color: vehicleForm.color.trim() || null,
          model: vehicleForm.model.trim() || null,
          isActive: Boolean(vehicleForm.isActive),
          soatNumber: vehicleForm.soatNumber.trim() || null,
          soatExpiresAt: dateInputToIsoOrNull(vehicleForm.soatExpiresAt),
          tecnicomecanicaNumber: vehicleForm.tecnicomecanicaNumber.trim() || null,
          tecnicomecanicaExpiresAt: dateInputToIsoOrNull(vehicleForm.tecnicomecanicaExpiresAt),
        }),
      });

      setMessage("Vehículo/documentos guardados ✅");
      await loadProfile();
    } catch (e: any) {
      setError(e?.message || "No se pudo guardar vehículo/documentos");
    } finally {
      setSavingVehicle(false);
    }
  }

  async function saveDocumentCheck(
    type: string,
    payload: {
      status: string;
      documentNumber?: string | null;
      expiresAt?: string | null;
      internalNotes?: string | null;
      waiverReason?: string | null;
      waiverExpiresAt?: string | null;
    }
  ) {
    setSavingDocument(type);
    setError(null);
    setMessage(null);

    try {
      await apiFetch(`/drivers/admin/${driverId}/documents`, {
        method: "PATCH",
        body: JSON.stringify({
          type,
          ...payload,
          receivedAt: new Date().toISOString(),
        }),
      });

      const docsRes = await apiFetch<any>(`/drivers/admin/${driverId}/documents`);
      setDocumentChecks(Array.isArray(docsRes?.documents) ? docsRes.documents : []);
      setMessage("Aval documental guardado ✅");
    } catch (e: any) {
      setError(e?.message || "No se pudo guardar el aval documental");
    } finally {
      setSavingDocument(null);
    }
  }


  const photoSrc = buildDriverPhotoSrc(profile?.user?.profileImageUrl ?? null);

  return (
    <main className="p-4 md:p-6 space-y-5">
      <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <div>
          <button
            type="button"
            onClick={() => router.push("/drivers")}
            className="mb-3 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50"
          >
            ← Volver a Workers
          </button>
          <div className="text-sm text-slate-500">KroniX Control Center</div>
          <h1 className="mt-1 text-2xl font-black text-slate-950">Perfil del Worker</h1>
          <p className="mt-1 text-sm text-slate-600">
            Administración completa de tipos autorizados, Wallet KRONIX, documentación y actividad.
          </p>
        </div>

        <div className="rounded-full border border-emerald-200 bg-emerald-50 px-4 py-2 text-xs font-bold text-emerald-700">
          {effectiveCitySlug ? `Ciudad activa: ${cityLabel}` : "Vista global"}
        </div>
      </div>

      {error ? (
        <div className="rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm text-rose-800">
          {error}
        </div>
      ) : null}

      {message ? (
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800">
          {message}
        </div>
      ) : null}

      {loading ? (
        <div className="rounded-2xl border border-slate-200 bg-white p-6 text-sm text-slate-600 shadow-sm">
          Cargando perfil del worker...
        </div>
      ) : profile ? (
        <>
          <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="flex min-w-0 items-center gap-4">
                <div className="relative grid h-20 w-20 shrink-0 place-items-center overflow-hidden rounded-2xl bg-slate-900 text-xl font-black text-white">
                  {String(profile.user?.name ?? "WK")
                    .split(/\s+/)
                    .filter(Boolean)
                    .slice(0, 2)
                    .map((x) => x[0]?.toUpperCase())
                    .join("") || "WK"}
                  {photoSrc ? (
                    <img
                      src={photoSrc}
                      alt="Foto oficial del worker"
                      className="absolute inset-0 h-full w-full object-cover"
                      onError={(e) => {
                        e.currentTarget.style.display = "none";
                      }}
                    />
                  ) : null}
                </div>
                <div className="min-w-0">
                  <h2 className="truncate text-xl font-black text-slate-950">{profile.user.name}</h2>
                  <div className="mt-1 text-sm text-slate-600">
                    {profile.user.phone} {profile.user.email ? `· ${profile.user.email}` : ""}
                  </div>
                  <div className="mt-1 font-mono text-xs text-slate-400">{profile.user.id}</div>
                </div>
              </div>

              <div className="flex max-w-2xl flex-wrap justify-end gap-2">
                {selectedServiceKeys.length > 0
                  ? availableServices
                      .filter((service) =>
                        selectedServiceKeys.includes(
                          String(service.serviceKey ?? "").trim().toUpperCase()
                        )
                      )
                      .map((service) => (
                        <span
                          key={service.id || service.serviceKey}
                          className="inline-flex items-center gap-1 rounded-full border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-bold text-blue-800"
                        >
                          {service.icon ? <span>{service.icon}</span> : null}
                          {service.shortName || service.name || service.serviceKey}
                        </span>
                      ))
: (
                      <span className="rounded-full border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-bold text-slate-500">
                        Sin servicios autorizados
                      </span>
                    )}
              </div>
            </div>
          </section>

          <div className="grid gap-4 md:grid-cols-6">
            <StatCard label="Nivel" value={levelLabel(profile.driverProfile?.level)} />
            <StatCard label="Rating" value={Number(profile.driverProfile?.rating ?? 0).toFixed(1)} />
            <StatCard label="Estado" value={profile.driverProfile?.isActive ? "Activo" : "Inactivo"} />
            <StatCard
              label="Servicios"
              value={String(
                selectedServiceKeys.length
              )}
              hint={workerTypeHint}
            />
            <StatCard label="Saldo KRONIX" value={formatCOP(Number(workerWalletData?.wallet?.totalAvailableCOP ?? 0))} />
            <StatCard label="Puede operar" value={eligibility?.canOperate ? "Sí" : "No"} />
          </div>

          <section className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm">
            <div className="flex flex-wrap gap-2">
              <TabButton active={tab === "GENERAL"} label="General" onClick={() => setTab("GENERAL")} />
              <TabButton active={tab === "TYPES"} label="Tipos autorizados" onClick={() => setTab("TYPES")} />
              <TabButton active={tab === "WALLET"} label="Wallet KRONIX" onClick={() => setTab("WALLET")} />
              <TabButton active={tab === "VEHICLE"} label="Vehículo" onClick={() => setTab("VEHICLE")} />
              <TabButton active={tab === "DOCUMENTS"} label="Documentos" onClick={() => setTab("DOCUMENTS")} />
              <TabButton active={tab === "HISTORY"} label="Historial" onClick={() => setTab("HISTORY")} />
            </div>
          </section>

          {tab === "GENERAL" ? (
            <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <h3 className="text-lg font-black text-slate-950">General</h3>

              <div className="mt-4 rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div className="mb-4">
                  <div className="text-sm font-black text-slate-900">Información editable del trabajador</div>
                  <p className="mt-1 text-xs text-slate-500">
                    Estos cambios administran identidad, credenciales, ciudad y estado del Worker.
                    No modifican los servicios autorizados de la pestaña Tipos autorizados.
                  </p>
                </div>

                <div className="grid gap-3 md:grid-cols-2">
                  <label className="block">
                    <span className="text-xs font-bold uppercase tracking-wide text-slate-500">Nombre</span>
                    <input
                      className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-slate-100"
                      value={generalForm.name}
                      disabled={savingGeneral}
                      onChange={(e) => setGeneralForm((s) => ({ ...s, name: e.target.value }))}
                    />
                  </label>

                  <label className="block">
                    <span className="text-xs font-bold uppercase tracking-wide text-slate-500">Teléfono / usuario</span>
                    <input
                      className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-slate-100"
                      value={generalForm.phone}
                      disabled={savingGeneral}
                      onChange={(e) => setGeneralForm((s) => ({ ...s, phone: e.target.value }))}
                    />
                  </label>

                  <label className="block">
                    <span className="text-xs font-bold uppercase tracking-wide text-slate-500">Email</span>
                    <input
                      type="email"
                      className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-slate-100"
                      value={generalForm.email}
                      disabled={savingGeneral}
                      onChange={(e) => setGeneralForm((s) => ({ ...s, email: e.target.value }))}
                    />
                  </label>

                  <label className="block">
                    <span className="text-xs font-bold uppercase tracking-wide text-slate-500">Documento</span>
                    <input
                      className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-slate-100"
                      value={generalForm.documentId}
                      disabled={savingGeneral}
                      onChange={(e) => setGeneralForm((s) => ({ ...s, documentId: e.target.value }))}
                    />
                  </label>

                  <label className="block">
                    <span className="text-xs font-bold uppercase tracking-wide text-slate-500">Ciudad asignada</span>
                    <select
                      className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-slate-100"
                      value={generalForm.citySlug}
                      disabled={savingGeneral}
                      onChange={(e) => setGeneralForm((s) => ({ ...s, citySlug: e.target.value }))}
                    >
                      {!cities.some((city) => city.slug === generalForm.citySlug) && generalForm.citySlug ? (
                        <option value={generalForm.citySlug}>{profile.driverProfile?.city?.name || cityLabel || generalForm.citySlug}</option>
                      ) : null}
                      <option value="">Seleccionar ciudad...</option>
                      {cities.map((city) => (
                        <option key={city.id || city.slug} value={city.slug}>
                          {city.name}{city.department ? `, ${city.department}` : ""}
                        </option>
                      ))}
                    </select>
                  </label>

                  <label className="block">
                    <span className="text-xs font-bold uppercase tracking-wide text-slate-500">Nueva contraseña</span>
                    <input
                      type="password"
                      autoComplete="new-password"
                      placeholder="Dejar en blanco para conservar la actual"
                      className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-slate-100"
                      value={generalForm.password}
                      disabled={savingGeneral}
                      onChange={(e) => setGeneralForm((s) => ({ ...s, password: e.target.value }))}
                    />
                    <span className="mt-1 block text-[11px] text-slate-500">Mínimo 6 caracteres si deseas cambiarla.</span>
                  </label>
                </div>

                <div className="mt-4 flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-3 sm:flex-row sm:items-center sm:justify-between">
                  <label className="flex items-center gap-3 text-sm font-semibold text-slate-800">
                    <input
                      type="checkbox"
                      checked={generalForm.isActive}
                      disabled={savingGeneral}
                      onChange={(e) => setGeneralForm((s) => ({ ...s, isActive: e.target.checked }))}
                    />
                    Worker activo
                  </label>

                  <button
                    type="button"
                    onClick={() => void saveGeneral()}
                    disabled={savingGeneral}
                    className="rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-bold text-white hover:bg-slate-800 disabled:opacity-60"
                  >
                    {savingGeneral ? "Guardando..." : "Guardar información general"}
                  </button>
                </div>
              </div>

              <div className="mt-5 rounded-2xl border border-sky-200 bg-sky-50 p-4">
                <div className="flex flex-col gap-4 lg:flex-row lg:items-center">
                  <div className="relative grid h-24 w-24 shrink-0 place-items-center overflow-hidden rounded-2xl bg-slate-900 text-lg font-black text-white ring-1 ring-sky-200">
                    {String(profile.user?.name ?? "WK")
                      .split(/\s+/)
                      .filter(Boolean)
                      .slice(0, 2)
                      .map((x) => x[0]?.toUpperCase())
                      .join("") || "WK"}

                    {buildDriverPhotoSrc(
                      normalizeDriverPhotoPath(photoFileName)
                    ) ? (
                      <img
                        key={photoFileName}
                        src={`${buildDriverPhotoSrc(
                          normalizeDriverPhotoPath(photoFileName)
                        )}?v=${encodeURIComponent(photoFileName)}`}
                        alt="Vista previa de la foto oficial"
                        className="absolute inset-0 h-full w-full object-cover"
                        onError={(e) => {
                          e.currentTarget.style.display = "none";
                        }}
                      />
                    ) : null}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="text-sm font-black text-sky-950">
                      Foto oficial del trabajador
                    </div>

                    <p className="mt-1 text-xs leading-5 text-sky-800">
                      Escribe únicamente el nombre exacto del archivo que ya copiaste en
                      <span className="font-mono font-bold">
                        {" "}public/branding/Driver_Pictures/
                      </span>
                      . La ruta completa se guarda automáticamente en Neon.
                    </p>

                    <div className="mt-3 flex flex-col gap-2 sm:flex-row">
                      <input
                        className="min-w-0 flex-1 rounded-xl border border-sky-200 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-sky-100"
                        placeholder="Ej: Driver1.jpg"
                        value={photoFileName}
                        disabled={savingPhoto}
                        onChange={(e) =>
                          setPhotoFileName(
                            driverPhotoFileNameFromUrl(e.target.value)
                          )
                        }
                      />

                      <button
                        type="button"
                        onClick={saveOfficialPhoto}
                        disabled={savingPhoto || !photoFileName.trim()}
                        className="rounded-xl bg-sky-700 px-4 py-2 text-sm font-bold text-white hover:bg-sky-800 disabled:opacity-60"
                      >
                        {savingPhoto ? "Guardando..." : "Guardar foto oficial"}
                      </button>
                    </div>

                    <div className="mt-2 text-[11px] text-sky-700">
                      Ruta que se guardará:{" "}
                      <span className="font-mono font-semibold">
                        {normalizeDriverPhotoPath(photoFileName) || "—"}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {eligibility?.reasons?.length ? (
                <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
                  <div className="font-black">Novedades de elegibilidad</div>
                  <ul className="mt-2 list-disc pl-5">
                    {eligibility.reasons.map((reason: string) => <li key={reason}>{reason}</li>)}
                  </ul>
                </div>
              ) : null}
            </section>
          ) : null}

          {tab === "TYPES" ? (
            <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <h3 className="text-lg font-black text-slate-950">Servicios autorizados</h3>
              <p className="mt-1 text-sm text-slate-600">Controla exactamente cuáles servicios dinámicos puede aceptar este trabajador.</p>

              {workerTypesData?.pendingOnboarding ? (
                <div className="mt-4 rounded-2xl border border-rose-200 bg-rose-50 px-4 py-3 text-sm font-semibold text-rose-800">
                  🔴 Nueva solicitud de onboarding pendiente de revisión.
                </div>
              ) : null}

              <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                {availableServices.map((service) => {
                  const serviceKey = String(service.serviceKey ?? "").trim().toUpperCase();
                  const checked = selectedServiceKeys.includes(serviceKey);
                  return (
                    <label
                      key={service.id || serviceKey}
                      className={[
                        "cursor-pointer rounded-2xl border p-4 transition",
                        checked
                          ? "border-blue-400 bg-blue-50 text-blue-950 ring-2 ring-blue-100"
                          : "border-slate-200 bg-slate-50 text-slate-600 hover:bg-white",
                      ].join(" ")}
                    >
                      <div className="flex items-start gap-3">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() =>
                            setSelectedServiceKeys((current) =>
                              checked
                                ? current.filter((key) => key !== serviceKey)
                                : [...current, serviceKey]
                            )
                          }
                        />
                        <div>
                          <div className="text-sm font-black">{service.icon || "⚙️"} {service.shortName || service.name}</div>
                          <div className="mt-1 text-xs opacity-80">{service.workerLabel}</div>
                          {service.description ? <div className="mt-2 text-xs leading-5 opacity-70">{service.description}</div> : null}
                        </div>
                      </div>
                    </label>
                  );
                })}
              </div>

              {availableServices.length === 0 ? (
                <div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
                  No hay servicios dinámicos activos para esta ciudad.
                </div>
              ) : null}

              <button
                type="button"
                onClick={saveWorkerTypes}
                disabled={savingTypes || selectedServiceKeys.length === 0}
                className="mt-4 rounded-xl bg-emerald-700 px-4 py-2 text-sm font-bold text-white hover:bg-emerald-800 disabled:opacity-60"
              >
                {savingTypes ? "Guardando..." : "Guardar servicios"}
              </button>
            </section>
          ) : null}

          {tab === "WALLET" ? (
            <section className="rounded-2xl border border-blue-200 bg-blue-50 p-5 shadow-sm">
              <div className="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                <div>
                  <h3 className="text-lg font-black text-blue-950">Wallet KRONIX</h3>
                  <div className="mt-2 text-4xl font-black text-blue-950">
                    {formatCOP(Number(workerWalletData?.wallet?.totalAvailableCOP ?? 0))}
                  </div>
                  <div className="mt-1 text-sm text-blue-800">
                    Cash: {formatCOP(Number(workerWalletData?.wallet?.cashBalanceCOP ?? 0))} · Bonus: {formatCOP(Number(workerWalletData?.wallet?.bonusBalanceCOP ?? 0))}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={loadWallet}
                  className="rounded-xl border border-blue-200 bg-white px-4 py-2 text-sm font-bold text-blue-800 hover:bg-blue-50"
                >
                  Refrescar
                </button>
              </div>

              <div className="mt-5 grid gap-3 md:grid-cols-3">
                <input
                  className="rounded-xl border border-blue-200 bg-white px-3 py-2 text-sm"
                  placeholder="Valor COP"
                  value={walletAmountCOP}
                  onChange={(e) => setWalletAmountCOP(e.target.value.replace(/\D/g, ""))}
                />
                <input
                  className="rounded-xl border border-blue-200 bg-white px-3 py-2 text-sm md:col-span-2"
                  placeholder="Nota de auditoría"
                  value={walletNote}
                  onChange={(e) => setWalletNote(e.target.value)}
                />
              </div>

              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => adjustWorkerWallet(1)}
                  disabled={savingWallet}
                  className="rounded-xl bg-blue-700 px-4 py-2 text-sm font-bold text-white hover:bg-blue-800 disabled:opacity-60"
                >
                  + Recargar
                </button>
                <button
                  type="button"
                  onClick={() => adjustWorkerWallet(-1)}
                  disabled={savingWallet}
                  className="rounded-xl border border-blue-200 bg-white px-4 py-2 text-sm font-bold text-blue-800 hover:bg-blue-50 disabled:opacity-60"
                >
                  - Debitar
                </button>
              </div>

              <div className="mt-5 overflow-hidden rounded-2xl border border-blue-100 bg-white">
                {(workerWalletData?.items ?? []).length ? (
                  (workerWalletData?.items ?? []).map((tx: any) => (
                    <div key={tx.id} className="border-b border-blue-50 px-4 py-3 text-sm last:border-b-0">
                      <div className="flex items-center justify-between gap-3">
                        <span className="font-black text-slate-900">{formatCOP(Number(tx.amountCOP ?? 0))}</span>
                        <span className="text-xs text-slate-500">{tx.type}</span>
                      </div>
                      <div className="mt-1 text-xs text-slate-500">{tx.note || tx.reference || "Movimiento"}</div>
                    </div>
                  ))
                ) : (
                  <div className="px-4 py-5 text-sm text-slate-500">Sin movimientos todavía.</div>
                )}
              </div>
            </section>
          ) : null}

          {tab === "VEHICLE" ? (
            <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <h3 className="text-lg font-black text-slate-950">Vehículo</h3>
              <div className="mt-4 grid gap-3 md:grid-cols-2">
                <Input label="Placa" value={vehicleForm.plate} onChange={(v) => setVehicleForm((p) => ({ ...p, plate: v }))} />
                <Input label="Marca" value={vehicleForm.brand} onChange={(v) => setVehicleForm((p) => ({ ...p, brand: v }))} />
                <Input label="Color" value={vehicleForm.color} onChange={(v) => setVehicleForm((p) => ({ ...p, color: v }))} />
                <Input label="Modelo / Año" value={vehicleForm.model} onChange={(v) => setVehicleForm((p) => ({ ...p, model: v }))} />
                <Input label="SOAT número" value={vehicleForm.soatNumber} onChange={(v) => setVehicleForm((p) => ({ ...p, soatNumber: v }))} />
                <Input label="SOAT vence" type="date" value={vehicleForm.soatExpiresAt} onChange={(v) => setVehicleForm((p) => ({ ...p, soatExpiresAt: v }))} />
                <Input label="Tecnomecánica número" value={vehicleForm.tecnicomecanicaNumber} onChange={(v) => setVehicleForm((p) => ({ ...p, tecnicomecanicaNumber: v }))} />
                <Input label="Tecnomecánica vence" type="date" value={vehicleForm.tecnicomecanicaExpiresAt} onChange={(v) => setVehicleForm((p) => ({ ...p, tecnicomecanicaExpiresAt: v }))} />
              </div>
              <label className="mt-4 flex items-center gap-2 text-sm text-slate-700">
                <input type="checkbox" checked={vehicleForm.isActive} onChange={(e) => setVehicleForm((p) => ({ ...p, isActive: e.target.checked }))} />
                Vehículo activo
              </label>
              <button
                type="button"
                onClick={saveVehicle}
                disabled={savingVehicle}
                className="mt-4 rounded-xl bg-slate-900 px-4 py-2 text-sm font-bold text-white hover:bg-slate-800 disabled:opacity-60"
              >
                {savingVehicle ? "Guardando..." : "Guardar vehículo"}
              </button>
            </section>
          ) : null}

          {tab === "DOCUMENTS" ? (
            <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
              <div>
                <h3 className="text-lg font-black text-slate-950">Documentos</h3>
                <p className="mt-1 text-xs text-slate-500">
                  Administra estado, número, vencimiento, notas internas y avales temporales de cada documento.
                </p>
              </div>

              <div className="mt-4 space-y-3">
                {DOCUMENT_TYPES.map((type) => {
                  const doc = documentChecks.find((item) => item.type === type) ?? null;

                  return (
                    <WorkerDocumentRow
                      key={type}
                      type={type}
                      label={DOCUMENT_LABELS[type] ?? type}
                      doc={doc}
                      saving={savingDocument === type}
                      onSave={saveDocumentCheck}
                    />
                  );
                })}
              </div>
            </section>
          ) : null}

          {tab === "HISTORY" ? (
            <section className="grid gap-4 lg:grid-cols-2">
              <HistoryTable title="Últimos pedidos" items={profile.history?.orders ?? []} />
              <HistoryTable title="Últimos payouts" items={profile.history?.payouts ?? []} />
            </section>
          ) : null}
        </>
      ) : (
        <div className="rounded-2xl border border-slate-200 bg-white p-6 text-sm text-slate-600 shadow-sm">
          No se encontró el worker.
        </div>
      )}
    </main>
  );
}


function WorkerDocumentRow({
  type,
  label,
  doc,
  saving,
  onSave,
}: {
  type: string;
  label: string;
  doc: DriverDocumentCheck | null;
  saving: boolean;
  onSave: (
    type: string,
    payload: {
      status: string;
      documentNumber?: string | null;
      expiresAt?: string | null;
      internalNotes?: string | null;
      waiverReason?: string | null;
      waiverExpiresAt?: string | null;
    }
  ) => Promise<void>;
}) {
  const [status, setStatus] = useState(doc?.status ?? "PENDING");
  const [documentNumber, setDocumentNumber] = useState(doc?.documentNumber ?? "");
  const [expiresAt, setExpiresAt] = useState(isoToDateInput(doc?.expiresAt ?? null));
  const [internalNotes, setInternalNotes] = useState(doc?.internalNotes ?? "");
  const [waiverReason, setWaiverReason] = useState(doc?.waiverReason ?? "");
  const [waiverExpiresAt, setWaiverExpiresAt] = useState(
    isoToDateInput(doc?.waiverExpiresAt ?? null)
  );

  useEffect(() => {
    setStatus(doc?.status ?? "PENDING");
    setDocumentNumber(doc?.documentNumber ?? "");
    setExpiresAt(isoToDateInput(doc?.expiresAt ?? null));
    setInternalNotes(doc?.internalNotes ?? "");
    setWaiverReason(doc?.waiverReason ?? "");
    setWaiverExpiresAt(isoToDateInput(doc?.waiverExpiresAt ?? null));
  }, [doc]);

  const normalizedStatus = String(status ?? "PENDING").toUpperCase();
  const isTemporary = normalizedStatus === "TEMPORARY_APPROVED";

  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-start lg:justify-between">
        <div>
          <div className="text-sm font-black text-slate-950">{label}</div>
          <div className="mt-0.5 font-mono text-[11px] text-slate-400">{type}</div>
          <span
            className={[
              "mt-2 inline-flex rounded-full border px-3 py-1 text-xs font-bold",
              statusBadgeClass(normalizedStatus),
            ].join(" ")}
          >
            {normalizedStatus}
          </span>
        </div>

        <div className="flex flex-wrap gap-2">
          {["PENDING", "RECEIVED", "APPROVED", "REJECTED", "TEMPORARY_APPROVED"].map(
            (nextStatus) => (
              <button
                key={nextStatus}
                type="button"
                onClick={() => setStatus(nextStatus)}
                disabled={saving}
                className={[
                  "rounded-xl border px-3 py-2 text-[11px] font-bold disabled:opacity-60",
                  normalizedStatus === nextStatus
                    ? "border-slate-900 bg-slate-900 text-white"
                    : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50",
                ].join(" ")}
              >
                {nextStatus}
              </button>
            )
          )}
        </div>
      </div>

      <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-4">
        <label className="block">
          <span className="text-xs font-bold text-slate-600">Número de documento</span>
          <input
            className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-200"
            value={documentNumber}
            disabled={saving}
            onChange={(e) => setDocumentNumber(e.target.value)}
            placeholder="Ej: ASDFG123456"
          />
        </label>

        <label className="block">
          <span className="text-xs font-bold text-slate-600">Fecha de vencimiento</span>
          <input
            type="date"
            className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-200"
            value={expiresAt}
            disabled={saving}
            onChange={(e) => setExpiresAt(e.target.value)}
          />
        </label>

        <label className="block md:col-span-2">
          <span className="text-xs font-bold text-slate-600">Nota interna</span>
          <input
            className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-200"
            value={internalNotes}
            disabled={saving}
            onChange={(e) => setInternalNotes(e.target.value)}
            placeholder="Ej: documento revisado físicamente"
          />
        </label>

        {isTemporary ? (
          <>
            <label className="block xl:col-span-3">
              <span className="text-xs font-bold text-blue-700">Razón del aval temporal</span>
              <input
                className="mt-1 w-full rounded-xl border border-blue-200 bg-blue-50 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-100"
                value={waiverReason}
                disabled={saving}
                onChange={(e) => setWaiverReason(e.target.value)}
                placeholder="Ej: documento físico pendiente de actualización"
              />
            </label>

            <label className="block">
              <span className="text-xs font-bold text-blue-700">Aval temporal hasta</span>
              <input
                type="date"
                className="mt-1 w-full rounded-xl border border-blue-200 bg-blue-50 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-blue-100"
                value={waiverExpiresAt}
                disabled={saving}
                onChange={(e) => setWaiverExpiresAt(e.target.value)}
              />
            </label>
          </>
        ) : null}
      </div>

      <div className="mt-4 flex justify-end">
        <button
          type="button"
          disabled={saving}
          onClick={() =>
            onSave(type, {
              status: normalizedStatus,
              documentNumber: documentNumber.trim() || null,
              expiresAt: dateInputToIsoOrNull(expiresAt),
              internalNotes: internalNotes.trim() || null,
              waiverReason: isTemporary ? waiverReason.trim() || null : null,
              waiverExpiresAt: isTemporary ? dateInputToIsoOrNull(waiverExpiresAt) : null,
            })
          }
          className="rounded-xl bg-slate-900 px-4 py-2 text-xs font-bold text-white hover:bg-slate-800 disabled:opacity-60"
        >
          {saving ? "Guardando..." : "Guardar documento"}
        </button>
      </div>
    </div>
  );
}


function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3">
      <div className="text-xs font-bold uppercase text-slate-500">{label}</div>
      <div className="mt-1 text-sm font-bold text-slate-900">{value}</div>
    </div>
  );
}

function Input({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type?: string;
}) {
  return (
    <label className="block">
      <span className="text-xs font-bold text-slate-600">{label}</span>
      <input
        type={type}
        className="mt-1 w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-slate-200"
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </label>
  );
}

function HistoryTable({ title, items }: { title: string; items: any[] }) {
  return (
    <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
      <div className="border-b border-slate-100 bg-slate-50 px-4 py-3 font-black text-slate-900">{title}</div>
      <div className="overflow-auto">
        <table className="min-w-full text-sm">
          <thead className="bg-white">
            <tr className="border-b border-slate-100 text-left text-xs text-slate-500">
              <th className="px-4 py-3">ID</th>
              <th className="px-4 py-3">Estado</th>
              <th className="px-4 py-3 text-right">Valor</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {items.slice(0, 20).map((item) => (
              <tr key={item.id}>
                <td className="px-4 py-3 font-mono text-xs text-slate-600">{item.id}</td>
                <td className="px-4 py-3 text-xs text-slate-700">{String(item.status ?? item.type ?? "—")}</td>
                <td className="px-4 py-3 text-right text-xs font-bold text-slate-900">
                  {formatCOP(Number(item.amountCOP ?? item.driverPayoutCOP ?? 0))}
                </td>
              </tr>
            ))}
            {!items.length ? (
              <tr>
                <td className="px-4 py-8 text-center text-slate-500" colSpan={3}>
                  Sin historial todavía.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}
